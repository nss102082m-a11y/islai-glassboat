const playButton = document.getElementById('playButton');
playButton.addEventListener('click', () => {
  const audio = new Audio('assets/demo_sound.mp3');
  audio.play();
});