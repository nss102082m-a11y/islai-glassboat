self.addEventListener('install', e => {
  e.waitUntil(caches.open('islai-cache').then(cache => cache.addAll(['/', '/index.html', '/app.js', '/assets/logo_main.png'])));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(resp => resp || fetch(e.request)));
});